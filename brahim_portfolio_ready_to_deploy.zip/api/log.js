// Vercel serverless function: /api/log
// Set DISCORD_WEBHOOK_URL in Vercel Project Settings > Environment Variables.
// Never place the webhook URL in frontend HTML or commit it to source control.
module.exports = async function handler(req, res) {
  res.setHeader('Cache-Control', 'no-store');
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST');
    return res.status(405).json({ error: 'Method not allowed' });
  }

  // Same-origin guard; supports Vercel preview deployments as well as production.
  const origin = req.headers.origin;
  const host = req.headers['x-forwarded-host'] || req.headers.host;
  if (origin && host) {
    try {
      const originHost = new URL(origin).host;
      if (originHost !== host) return res.status(403).json({ error: 'Forbidden origin' });
    } catch (_) {
      return res.status(403).json({ error: 'Invalid origin' });
    }
  }

  const allowedEvents = new Set(['page_view', 'project_open', 'contact_click', 'rating']);
  const body = typeof req.body === 'string' ? (() => { try { return JSON.parse(req.body); } catch (_) { return {}; } })() : (req.body || {});
  const event = typeof body.event === 'string' ? body.event : '';
  const details = typeof body.details === 'string' ? body.details.slice(0, 180) : '';
  if (!allowedEvents.has(event)) return res.status(400).json({ error: 'Invalid event' });

  const webhook = process.env.DISCORD_WEBHOOK_URL;
  if (!webhook) return res.status(503).json({ error: 'Logging is not configured' });
  let webhookUrl;
  try { webhookUrl = new URL(webhook); } catch (_) { return res.status(500).json({ error: 'Invalid webhook configuration' }); }
  if (!['discord.com', 'discordapp.com'].includes(webhookUrl.hostname) || !webhookUrl.pathname.startsWith('/api/webhooks/')) {
    return res.status(500).json({ error: 'Invalid webhook configuration' });
  }

  const labels = {
    page_view: 'Portfolio visit',
    project_open: 'Project opened',
    contact_click: 'Contact link clicked',
    rating: 'Portfolio rating submitted'
  };
  const payload = {
    username: 'Portfolio Activity',
    embeds: [{
      title: labels[event],
      description: details || 'No extra details',
      color: 0xD7264D,
      timestamp: new Date().toISOString(),
      footer: { text: 'Brahim Saadi Portfolio' }
    }]
  };

  try {
    const response = await fetch(webhookUrl.toString(), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    if (!response.ok) {
      // Do not return Discord's response body or reveal the webhook URL to visitors.
      return res.status(502).json({ error: 'Notification delivery failed' });
    }
    return res.status(204).end();
  } catch (_) {
    return res.status(502).json({ error: 'Notification delivery failed' });
  }
};
