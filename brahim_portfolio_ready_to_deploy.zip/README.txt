BRAHIM SAADI PORTFOLIO — READY-TO-DEPLOY BUNDLE

FILES
- index.html: your portfolio with the original project cards/demos, ratings, Google Sheets ratings endpoint, and new Contact Me section.
- api/log.js: Vercel serverless endpoint that sends privacy-conscious activity notifications to Discord.
- .env.example: documents the required server-side environment variable.

WHAT IS ALREADY CONNECTED IN index.html
- Ratings POST and ratings feed use your existing Google Apps Script URL.
- Contact section links to Instagram @brah.vm and ibrahimpourtravail@gmail.com.
- The email address is also configured for the existing Get in Touch / Copy Email controls.
- Portfolio visit, project open, contact click, and successful rating events POST to /api/log.
- The Discord webhook secret is never put in the HTML.

DEPLOY
1. Extract this ZIP into the root of the SAME Vercel project you use for the portfolio.
2. Keep the file structure exactly like this:
     index.html
     api/log.js
     .env.example
3. In Vercel, open Project Settings > Environment Variables and set:
     DISCORD_WEBHOOK_URL = your Discord incoming webhook URL
   Use the webhook you already configured. Do not paste it into index.html or publish it.
4. Make sure the variable is enabled for the environment you deploy (Production, and Preview too if needed).
5. Redeploy the project after adding/updating the environment variable.
6. Open the deployed site and test a page visit, open a project, click a contact link, and submit a rating. The Google Sheets rating flow is separate from Discord event notifications.

IMPORTANT
- This bundle preserves the Google Apps Script endpoint currently in your HTML; it does not contain or expose your Discord webhook URL.
- If your existing Vercel project uses a different frontend output directory, put index.html and api/log.js in that project's root/output-compatible structure rather than deploying the HTML by itself.
- No webhook URL was present in the HTML, so the backend reads it from Vercel's DISCORD_WEBHOOK_URL environment variable.
